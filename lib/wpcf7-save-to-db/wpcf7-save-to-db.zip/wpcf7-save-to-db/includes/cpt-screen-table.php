<?php
    global $post;
    $post_id = get_the_ID( $post );
    $post_meta = get_post_meta( $post_id );
?>

<h4 style="margin-top: 20px;">
    <?php _e( 'Submission data', 'wpcf7-save-to-db' ); ?>
</h4>

<table class="wp-list-table widefat fixed striped emails" style="margin-top: 10px;">

    <thead>
        <tr>
            <th style="padding: 10px;" scope="col" class="manage-column column-receiver sortable asc">
                <?php _e( 'Key', 'wpcf7-save-to-db' ); ?>
            </th>
            <th style="padding: 10px;" scope="col" class="manage-column column-receiver sortable asc">
                <?php _e( 'Value', 'wpcf7-save-to-db' ); ?>
            </th>
        </tr>
    </thead>

    <tbody>

        <?php foreach ($post_meta as $key => $value) : ?>

            <?php if ( $key !== '_edit_lock' ) : ?>

                <tr>
                    <td style="padding: 10px;">
                        <?php echo strtoupper( $key ); ?>
                    </td>
                    <td style="padding: 10px;">
                        <?php echo $value[0]; ?>
                    </td>
                </tr>

            <?php endif; ?>

        <?php endforeach; ?>

    </tbody>

</table>
